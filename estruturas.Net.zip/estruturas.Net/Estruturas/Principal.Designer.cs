﻿namespace Estruturas
{
    partial class frmPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            pnlContainer = new Panel();
            pictureBox1 = new PictureBox();
            btnSair = new Button();
            pnlLogin = new Panel();
            btnLimpar = new Button();
            btnTestar = new Button();
            txtSenha = new TextBox();
            lblSenha = new Label();
            txtUsuario = new TextBox();
            lblUsuario = new Label();
            lsbMostra = new ListBox();
            lblRepeticao = new Label();
            pnlRepeticao = new Panel();
            btnMes = new Button();
            btnTanuki = new Button();
            btnFor = new Button();
            btnLista = new Button();
            btnTiktok = new Button();
            btnCanal = new Button();
            btnFelix = new Button();
            lblCondicional = new Label();
            pnlContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlLogin.SuspendLayout();
            pnlRepeticao.SuspendLayout();
            SuspendLayout();
            // 
            // pnlContainer
            // 
            pnlContainer.Anchor = AnchorStyles.None;
            pnlContainer.Controls.Add(pictureBox1);
            pnlContainer.Controls.Add(btnSair);
            pnlContainer.Controls.Add(pnlLogin);
            pnlContainer.Controls.Add(lsbMostra);
            pnlContainer.Controls.Add(lblRepeticao);
            pnlContainer.Controls.Add(pnlRepeticao);
            pnlContainer.Controls.Add(lblCondicional);
            pnlContainer.Location = new Point(44, 47);
            pnlContainer.Margin = new Padding(4, 5, 4, 5);
            pnlContainer.Name = "pnlContainer";
            pnlContainer.Size = new Size(1159, 989);
            pnlContainer.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(572, 66);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(418, 359);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(893, 763);
            btnSair.Margin = new Padding(4, 5, 4, 5);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(147, 63);
            btnSair.TabIndex = 11;
            btnSair.Text = "Sair do sistema";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // pnlLogin
            // 
            pnlLogin.BorderStyle = BorderStyle.Fixed3D;
            pnlLogin.Controls.Add(btnLimpar);
            pnlLogin.Controls.Add(btnTestar);
            pnlLogin.Controls.Add(txtSenha);
            pnlLogin.Controls.Add(lblSenha);
            pnlLogin.Controls.Add(txtUsuario);
            pnlLogin.Controls.Add(lblUsuario);
            pnlLogin.Location = new Point(103, 110);
            pnlLogin.Margin = new Padding(4, 5, 4, 5);
            pnlLogin.Name = "pnlLogin";
            pnlLogin.Size = new Size(384, 229);
            pnlLogin.TabIndex = 10;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(227, 148);
            btnLimpar.Margin = new Padding(4, 5, 4, 5);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(130, 38);
            btnLimpar.TabIndex = 4;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnTestar
            // 
            btnTestar.Location = new Point(227, 57);
            btnTestar.Margin = new Padding(4, 5, 4, 5);
            btnTestar.Name = "btnTestar";
            btnTestar.Size = new Size(130, 38);
            btnTestar.TabIndex = 1;
            btnTestar.Text = "Entrar";
            btnTestar.UseVisualStyleBackColor = true;
            btnTestar.Click += btnTestar_Click;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(29, 148);
            txtSenha.Margin = new Padding(4, 5, 4, 5);
            txtSenha.MaxLength = 20;
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(161, 31);
            txtSenha.TabIndex = 2;
            txtSenha.UseSystemPasswordChar = true;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(29, 117);
            lblSenha.Margin = new Padding(4, 0, 4, 0);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(60, 25);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha";
            // 
            // txtUsuario
            // 
            txtUsuario.Location = new Point(29, 57);
            txtUsuario.Margin = new Padding(4, 5, 4, 5);
            txtUsuario.MaxLength = 20;
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(161, 31);
            txtUsuario.TabIndex = 1;
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(29, 25);
            lblUsuario.Margin = new Padding(4, 0, 4, 0);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(72, 25);
            lblUsuario.TabIndex = 1;
            lblUsuario.Text = "Usuário";
            // 
            // lsbMostra
            // 
            lsbMostra.FormattingEnabled = true;
            lsbMostra.Location = new Point(533, 433);
            lsbMostra.Margin = new Padding(4, 5, 4, 5);
            lsbMostra.Name = "lsbMostra";
            lsbMostra.Size = new Size(507, 304);
            lsbMostra.TabIndex = 9;
            // 
            // lblRepeticao
            // 
            lblRepeticao.AutoSize = true;
            lblRepeticao.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblRepeticao.Location = new Point(103, 370);
            lblRepeticao.Margin = new Padding(4, 0, 4, 0);
            lblRepeticao.Name = "lblRepeticao";
            lblRepeticao.Size = new Size(279, 32);
            lblRepeticao.TabIndex = 8;
            lblRepeticao.Text = "Estruturas de repetição";
            // 
            // pnlRepeticao
            // 
            pnlRepeticao.BorderStyle = BorderStyle.Fixed3D;
            pnlRepeticao.Controls.Add(btnMes);
            pnlRepeticao.Controls.Add(btnTanuki);
            pnlRepeticao.Controls.Add(btnFor);
            pnlRepeticao.Controls.Add(btnLista);
            pnlRepeticao.Controls.Add(btnTiktok);
            pnlRepeticao.Controls.Add(btnCanal);
            pnlRepeticao.Controls.Add(btnFelix);
            pnlRepeticao.Location = new Point(103, 425);
            pnlRepeticao.Margin = new Padding(4, 5, 4, 5);
            pnlRepeticao.Name = "pnlRepeticao";
            pnlRepeticao.Size = new Size(384, 401);
            pnlRepeticao.TabIndex = 7;
            // 
            // btnMes
            // 
            btnMes.BackColor = Color.Crimson;
            btnMes.Font = new Font("Ink Free", 13.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMes.ForeColor = SystemColors.ButtonHighlight;
            btnMes.Location = new Point(47, 305);
            btnMes.Margin = new Padding(4, 5, 4, 5);
            btnMes.Name = "btnMes";
            btnMes.Size = new Size(293, 67);
            btnMes.TabIndex = 11;
            btnMes.Text = "Funcionário do Mês";
            btnMes.UseVisualStyleBackColor = false;
            btnMes.Click += btnMes_Click;
            // 
            // btnTanuki
            // 
            btnTanuki.BackColor = Color.DarkViolet;
            btnTanuki.Font = new Font("Comic Sans MS", 15F, FontStyle.Bold);
            btnTanuki.ForeColor = SystemColors.ButtonHighlight;
            btnTanuki.Location = new Point(209, 217);
            btnTanuki.Margin = new Padding(4, 5, 4, 5);
            btnTanuki.Name = "btnTanuki";
            btnTanuki.Size = new Size(130, 67);
            btnTanuki.TabIndex = 10;
            btnTanuki.Text = "Tanuki";
            btnTanuki.UseVisualStyleBackColor = false;
            btnTanuki.Click += btnTanuki_Click;
            // 
            // btnFor
            // 
            btnFor.BackColor = Color.Red;
            btnFor.ForeColor = SystemColors.Desktop;
            btnFor.Location = new Point(47, 17);
            btnFor.Margin = new Padding(4, 5, 4, 5);
            btnFor.Name = "btnFor";
            btnFor.Size = new Size(130, 67);
            btnFor.TabIndex = 9;
            btnFor.Text = "Fenix (1000x)";
            btnFor.UseVisualStyleBackColor = false;
            btnFor.Click += btnFor_Click;
            // 
            // btnLista
            // 
            btnLista.BackColor = SystemColors.Desktop;
            btnLista.ForeColor = SystemColors.Control;
            btnLista.Location = new Point(210, 113);
            btnLista.Margin = new Padding(4, 5, 4, 5);
            btnLista.Name = "btnLista";
            btnLista.Size = new Size(130, 67);
            btnLista.TabIndex = 8;
            btnLista.Text = "Produções";
            btnLista.UseVisualStyleBackColor = false;
            btnLista.Click += btnLista_Click;
            // 
            // btnTiktok
            // 
            btnTiktok.BackColor = Color.Navy;
            btnTiktok.ForeColor = SystemColors.Info;
            btnTiktok.Location = new Point(47, 113);
            btnTiktok.Margin = new Padding(4, 5, 4, 5);
            btnTiktok.Name = "btnTiktok";
            btnTiktok.Size = new Size(130, 67);
            btnTiktok.TabIndex = 7;
            btnTiktok.Text = "TikTok";
            btnTiktok.UseVisualStyleBackColor = false;
            btnTiktok.Click += btnTiktok_Click;
            // 
            // btnCanal
            // 
            btnCanal.BackColor = Color.Gold;
            btnCanal.ForeColor = SystemColors.ActiveCaptionText;
            btnCanal.Location = new Point(209, 17);
            btnCanal.Margin = new Padding(4, 5, 4, 5);
            btnCanal.Name = "btnCanal";
            btnCanal.Size = new Size(130, 67);
            btnCanal.TabIndex = 6;
            btnCanal.Text = "Canal";
            btnCanal.UseVisualStyleBackColor = false;
            btnCanal.Click += btnCanal_Click;
            // 
            // btnFelix
            // 
            btnFelix.Font = new Font("Cambria", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFelix.Location = new Point(47, 217);
            btnFelix.Margin = new Padding(4, 5, 4, 5);
            btnFelix.Name = "btnFelix";
            btnFelix.Size = new Size(130, 67);
            btnFelix.TabIndex = 5;
            btnFelix.Text = "Felix";
            btnFelix.UseVisualStyleBackColor = true;
            btnFelix.Click += btnFelix_Click;
            // 
            // lblCondicional
            // 
            lblCondicional.AutoSize = true;
            lblCondicional.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblCondicional.Location = new Point(103, 67);
            lblCondicional.Margin = new Padding(4, 0, 4, 0);
            lblCondicional.Name = "lblCondicional";
            lblCondicional.Size = new Size(262, 32);
            lblCondicional.TabIndex = 6;
            lblCondicional.Text = "Estrutura Condicional";
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.ForestGreen;
            ClientSize = new Size(1270, 1050);
            Controls.Add(pnlContainer);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(4, 5, 4, 5);
            Name = "frmPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tela Principal";
            WindowState = FormWindowState.Maximized;
            pnlContainer.ResumeLayout(false);
            pnlContainer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlLogin.ResumeLayout(false);
            pnlLogin.PerformLayout();
            pnlRepeticao.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlContainer;
        private ListBox lsbMostra;
        private Label lblRepeticao;
        private Panel pnlRepeticao;
        private Button btnTanuki;
        private Button btnFor;
        private Button btnLista;
        private Button btnTiktok;
        private Button btnCanal;
        private Button btnFelix;
        private Label lblCondicional;
        private Panel pnlLogin;
        private Button btnLimpar;
        private Button btnTestar;
        private TextBox txtSenha;
        private Label lblSenha;
        private TextBox txtUsuario;
        private Label lblUsuario;
        private Button btnSair;
        private PictureBox pictureBox1;
        private Button btnMes;
    }
}

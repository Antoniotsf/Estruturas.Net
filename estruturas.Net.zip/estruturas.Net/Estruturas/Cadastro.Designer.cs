﻿namespace Estruturas
{
    partial class frmCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCadastro));
            pibImagem = new PictureBox();
            btnFechar = new Button();
            LblWelcome = new Label();
            ((System.ComponentModel.ISupportInitialize)pibImagem).BeginInit();
            SuspendLayout();
            // 
            // pibImagem
            // 
            pibImagem.Image = (Image)resources.GetObject("pibImagem.Image");
            pibImagem.Location = new Point(67, 50);
            pibImagem.Margin = new Padding(4, 5, 4, 5);
            pibImagem.Name = "pibImagem";
            pibImagem.Size = new Size(416, 388);
            pibImagem.SizeMode = PictureBoxSizeMode.Zoom;
            pibImagem.TabIndex = 0;
            pibImagem.TabStop = false;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(979, 669);
            btnFechar.Margin = new Padding(4, 5, 4, 5);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(151, 67);
            btnFechar.TabIndex = 1;
            btnFechar.Text = "Sair";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // LblWelcome
            // 
            LblWelcome.AutoSize = true;
            LblWelcome.Font = new Font("Impact", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblWelcome.Location = new Point(565, 70);
            LblWelcome.Name = "LblWelcome";
            LblWelcome.Size = new Size(510, 44);
            LblWelcome.TabIndex = 2;
            LblWelcome.Text = "Seja Bem Vindo à área de Admin ;)";
            // 
            // frmCadastro
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(LblWelcome);
            Controls.Add(btnFechar);
            Controls.Add(pibImagem);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frmCadastro";
            Text = "Cadastro";
            ((System.ComponentModel.ISupportInitialize)pibImagem).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pibImagem;
        private Button btnFechar;
        private Label LblWelcome;
    }
}
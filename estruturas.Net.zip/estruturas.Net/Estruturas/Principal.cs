using System.Diagnostics;

namespace Estruturas
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string usuario = "Fenix Studios";
            string senha = "ReadyForThis123@";

            if (usuario == txtUsuario.Text & senha == txtSenha.Text)
            {
                frmCadastro cadastro = new frmCadastro();
                cadastro.FormBorderStyle = FormBorderStyle.None;
                cadastro.Bounds = Screen.PrimaryScreen.Bounds;
                cadastro.TopMost = true;
                cadastro.ShowDialog();
            }
            else
            {
                MessageBox.Show("Usuário ou senha incorretos!!", "Verificação",
                MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question
                );
                txtUsuario.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtUsuario.Clear();
            txtSenha.Clear();
            txtUsuario.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnFelix_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://www.youtube.com/@Felixmp4",
                UseShellExecute = true
            });
        }

        private void btnTiktok_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://www.tiktok.com/@fenix.studiostf",
                UseShellExecute = true
            });
        }

        private void btnFor_Click(object sender, EventArgs e)
        {

            lsbMostra.Items.Clear();

            for (int i = 0; i < 1000; i++)
            {
                lsbMostra.ForeColor = Color.Red;
                lsbMostra.Items.Add("Fenix Studios");
            }
        }

        private void btnCanal_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://www.youtube.com/@FenixStudios-tf",
                UseShellExecute = true
            });
        }

        private void btnLista_Click(object sender, EventArgs e)
        {
            List<string> producoes = new List<string>
            {
                "Cover - Don't You Forget(Reprise)",
                "Cover - Stayed Gone",
                "Anúncio 2026",
                "Cover - Ready For This",
                "Fandub - An Interview with Springtrap",
                "Cover - Poison",
                "Fandub - Comic 'Um dia no pós vida'",
                "Cover - Hell's Forever",
                "Cover - Brighter",
                "Fandub - A Little Bit Bad",
                "Cover - Once we Get Up There",
                "Cover - Paz na terra e muito amor",
                "Cover - Easy",
                "Fandub - Digital Hallucination",
                "Cover - Love in a Bottle",
                "Fandub - Abstraction",
                "Cover - Canção do Fracasso",
                "Cover - How Bad Can I Be?"
            };

            lsbMostra.Items.Clear();

            foreach (string item in producoes)
            {
                lsbMostra.Items.Add(item);
            }

        }

        private void btnTanuki_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://www.youtube.com/@Tanukizx",
                UseShellExecute = true
            });
        }

        private void btnMes_Click(object sender, EventArgs e)
        {
            lsbMostra.Items.Clear();
            lsbMostra.Items.Add("imagem");
        }
    }
}
